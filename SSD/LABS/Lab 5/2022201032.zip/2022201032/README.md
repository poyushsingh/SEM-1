1) index.html page:
	i have used used title 2022201032.
	and used external css named style.css.
	created class container inside which i have taken username and password from user and also there is a submit button ,clicking on which the user will be navigated to next page studentRecords.html
	
2) StudentRecords.html:
	mainly created two function myCreateFunction(),myDeleteFunction() which will be used to get the input from user for creating new rows in table and deleting last record.
